import controller.AppController;

public class Main {
    public static void main(String[] args) {
        try {
            new AppController().run();
        } catch (RuntimeException e) {
            System.err.println("\n[ERREUR FATALE] " + e.getMessage());
            System.err.println("Vérifiez que MySQL est démarré et que les identifiants dans DatabaseManager.java sont corrects.");
            System.exit(1);
        }
    }
}
