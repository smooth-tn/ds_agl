package dao;

import model.Client;
import model.Compte;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClientDAO {

    private final Connection con;

    public ClientDAO(Connection con) {
        this.con = con;
    }

    /** Returns the Client if credentials match, null otherwise. */
    public Client authentifier(String username, String password) {
        String sql = "SELECT * FROM CLIENT WHERE username = ? AND password = ? AND isBlocked = FALSE";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Client(
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("email"),
                    rs.getBoolean("isBlocked")
                );
            }
            return null;
        } catch (SQLException e) {
            System.err.println("[ClientDAO] Erreur authentification : " + e.getMessage());
            return null;
        }
    }

    /** Registers a new client. Returns true if created, false if username/email already exists. */
    public boolean creerClient(Compte compte) {
        String sql = "INSERT INTO CLIENT(username, password, email) VALUES (?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, compte.getUsername());
            ps.setString(2, compte.getMotDePass());
            ps.setString(3, compte.getEmail());
            return ps.executeUpdate() > 0;
        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("  [!] Ce username ou email est déjà utilisé.");
            return false;
        } catch (SQLException e) {
            System.err.println("[ClientDAO] Erreur création client : " + e.getMessage());
            return false;
        }
    }

    public boolean modifierPassword(int clientId, String newPassword) {
        String sql = "UPDATE CLIENT SET password = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newPassword);
            ps.setInt(2, clientId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[ClientDAO] Erreur modification mdp : " + e.getMessage());
            return false;
        }
    }

    public boolean bloquerClient(int id) {
        String sql = "UPDATE CLIENT SET isBlocked = TRUE WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[ClientDAO] Erreur blocage client : " + e.getMessage());
            return false;
        }
    }

    public boolean debloquerClient(int id) {
        String sql = "UPDATE CLIENT SET isBlocked = FALSE WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[ClientDAO] Erreur déblocage client : " + e.getMessage());
            return false;
        }
    }

    public Client chercherParId(int id) {
        String sql = "SELECT * FROM CLIENT WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next())
                return new Client(rs.getInt("id"), rs.getString("username"),
                                  rs.getString("email"), rs.getBoolean("isBlocked"));
            return null;
        } catch (SQLException e) {
            System.err.println("[ClientDAO] Erreur recherche client : " + e.getMessage());
            return null;
        }
    }

    public List<Client> tousLesClients() {
        List<Client> liste = new ArrayList<>();
        String sql = "SELECT * FROM CLIENT ORDER BY id";
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next())
                liste.add(new Client(rs.getInt("id"), rs.getString("username"),
                                     rs.getString("email"), rs.getBoolean("isBlocked")));
        } catch (SQLException e) {
            System.err.println("[ClientDAO] Erreur liste clients : " + e.getMessage());
        }
        return liste;
    }
}
