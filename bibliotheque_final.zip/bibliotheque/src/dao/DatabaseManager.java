package dao;

import java.sql.*;

public class DatabaseManager {

    private static DatabaseManager instance;
    private Connection con = null;

    // ---- Change these to match your MySQL setup ----
    private static final String URL      = "jdbc:mysql://localhost:3306/BIBLIOTHEQUEDB?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DB_USER  = "root";
    private static final String DB_PASS  = "123";
    // -------------------------------------------------

    private DatabaseManager() {}

    public static DatabaseManager getInstance() {
        if (instance == null) instance = new DatabaseManager();
        return instance;
    }

    public void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(URL, DB_USER, DB_PASS);
            System.out.println("[DB] Connexion établie.");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("[DB] Driver MySQL introuvable !");
        } catch (SQLException e) {
            throw new RuntimeException("[DB] Connexion échouée : " + e.getMessage());
        }
    }

    public void disconnect() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("[DB] Connexion fermée.");
            }
        } catch (SQLException e) {
            System.err.println("[DB] Erreur à la fermeture : " + e.getMessage());
        }
    }

    public Connection getConnection() {
        return con;
    }

    /** Creates all tables and seeds admin if DB is empty. */
    public void initSchema() {
        String[] sqls = {
            "CREATE TABLE IF NOT EXISTS CLIENT (" +
            "  id INT AUTO_INCREMENT PRIMARY KEY," +
            "  username VARCHAR(50) NOT NULL," +
            "  password VARCHAR(100) NOT NULL," +
            "  email VARCHAR(100) UNIQUE NOT NULL," +
            "  isBlocked BOOLEAN DEFAULT FALSE," +
            "  creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
            ")",

            "CREATE TABLE IF NOT EXISTS ADMINS (" +
            "  id INT AUTO_INCREMENT PRIMARY KEY," +
            "  username VARCHAR(50) NOT NULL," +
            "  password VARCHAR(100) NOT NULL," +
            "  email VARCHAR(100) UNIQUE NOT NULL," +
            "  creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
            ")",

            "CREATE TABLE IF NOT EXISTS LIVRE (" +
            "  id INT AUTO_INCREMENT PRIMARY KEY," +
            "  titre VARCHAR(150) NOT NULL," +
            "  auteur VARCHAR(100) NOT NULL," +
            "  categorie VARCHAR(100) NOT NULL," +
            "  isDispo BOOLEAN DEFAULT TRUE," +
            "  creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
            ")",

            "CREATE TABLE IF NOT EXISTS EMPRUNT (" +
            "  id INT AUTO_INCREMENT PRIMARY KEY," +
            "  client_id INT NOT NULL," +
            "  livre_id INT NOT NULL," +
            "  date_emprunt TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
            "  date_limite TIMESTAMP NOT NULL," +
            "  date_retour TIMESTAMP NULL DEFAULT NULL," +
            "  FOREIGN KEY (client_id) REFERENCES CLIENT(id)," +
            "  FOREIGN KEY (livre_id) REFERENCES LIVRE(id)" +
            ")"
        };

        try (Statement st = con.createStatement()) {
            for (String sql : sqls) st.executeUpdate(sql);

            // Seed default admin if table is empty
            ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM ADMINS");
            rs.next();
            if (rs.getInt(1) == 0) {
                st.executeUpdate("INSERT INTO ADMINS(username, password, email) VALUES ('admin','admin123','admin@bibliotheque.dz')");
                System.out.println("[DB] Admin par défaut créé  (user: admin / mdp: admin123)");
            }

            // Seed sample books if empty
            rs = st.executeQuery("SELECT COUNT(*) FROM LIVRE");
            rs.next();
            if (rs.getInt(1) == 0) {
                String[] books = {
                    "('Le Petit Prince','Antoine de Saint-Exupéry','Roman')",
                    "('1984','George Orwell','Science-Fiction')",
                    "('Sapiens','Yuval Noah Harari','Histoire')",
                    "('Clean Code','Robert C. Martin','Informatique')",
                    "('L''Alchimiste','Paulo Coelho','Roman')"
                };
                for (String b : books)
                    st.executeUpdate("INSERT INTO LIVRE(titre, auteur, categorie) VALUES " + b);
                System.out.println("[DB] Livres de démonstration ajoutés.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("[DB] Erreur init schéma : " + e.getMessage());
        }
    }
}
