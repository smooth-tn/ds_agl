package model;

public class Compte {
    private String email;
    private String motDePass;
    private String userName;

    public Compte(String userName, String email, String motDePass) {
        this.userName = userName;
        this.email = email;
        this.motDePass = motDePass;
    }

    public String getUsername()   { return userName; }
    public String getEmail()      { return email; }
    public String getMotDePass()  { return motDePass; }

    public void setEmail(String email)        { this.email = email; }
    public void setMotDePass(String motDePass){ this.motDePass = motDePass; }
    public void setUserName(String name)      { this.userName = name; }
}
