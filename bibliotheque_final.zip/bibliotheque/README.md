# 📚 Bibliothèque — Système de Gestion (Java Terminal)

Application Java en ligne de commande pour la gestion d'une bibliothèque.  
Architecture MVC + DAO, connexion MySQL via JDBC.

---

## 📁 Structure du projet

```
bibliotheque/
├── Main.java                        ← Point d'entrée
├── build.sh                         ← Script de compilation/exécution (Linux/Mac)
├── lib/
│   └── mysql-connector-j-9.6.0.jar  ← Driver JDBC MySQL
├── src/
│   ├── model/          ← Entités métier
│   │   ├── AbstractUser.java
│   │   ├── Admin.java
│   │   ├── Client.java
│   │   ├── Compte.java
│   │   ├── Date.java
│   │   ├── Emprunt.java
│   │   └── Livre.java
│   ├── dao/            ← Accès base de données
│   │   ├── DatabaseManager.java
│   │   ├── AdminDAO.java
│   │   ├── ClientDAO.java
│   │   ├── EmpruntDAO.java
│   │   └── LivreDAO.java
│   ├── controller/     ← Logique applicative
│   │   └── AppController.java
│   ├── view/           ← Interface terminal
│   │   └── View.java
│   └── utils/
│       └── EmailValidation.java
└── out/                ← Classes compilées (généré par build.sh)
```

---

## ⚙️ Prérequis

- **Java JDK 17+**
- **MySQL 8+** en cours d'exécution
- Une base de données nommée `BIBLIOTHEQUEDB` créée :
  ```sql
  CREATE DATABASE BIBLIOTHEQUEDB;
  ```

---

## 🔧 Configuration

Ouvrez `src/dao/DatabaseManager.java` et modifiez :

```java
private static final String DB_USER = "root";
private static final String DB_PASS = "123";      // ← votre mot de passe MySQL
```

Les tables sont créées **automatiquement** au premier lancement.  
Un admin par défaut et 5 livres de démo sont insérés automatiquement.

---

## 🚀 Compilation & Lancement

### Linux / macOS
```bash
chmod +x build.sh
./build.sh
```

### Manuellement
```bash
# Compilation
find src -name "*.java" > sources.txt
javac -encoding UTF-8 -cp lib/mysql-connector-j-9.6.0.jar -d out @sources.txt Main.java

# Exécution (Linux/Mac)
java -cp "out:lib/mysql-connector-j-9.6.0.jar" Main

# Exécution (Windows)
java -cp "out;lib/mysql-connector-j-9.6.0.jar" Main
```

### Via IntelliJ IDEA
1. Ouvrir le dossier `bibliotheque/` comme projet
2. Ajouter `lib/mysql-connector-j-9.6.0.jar` aux dépendances du projet
3. Marquer `src/` comme Sources Root
4. Exécuter `Main.java`

---

## 👤 Comptes par défaut

| Rôle          | Username | Mot de passe |
|---------------|----------|--------------|
| Administrateur| `admin`  | `admin123`   |

---

## ✅ Fonctionnalités

### Client
- Inscription / Connexion
- Consulter le catalogue de livres
- Rechercher un livre par titre
- Emprunter un livre (durée : 14 jours)
- Retourner un livre
- Voir ses emprunts actifs
- Voir son historique d'emprunts
- Changer son mot de passe

### Administrateur
- Consulter le catalogue complet
- Ajouter / Supprimer un livre
- Rechercher un livre par titre
- Lister tous les clients
- Bloquer / Débloquer un client
- Voir tous les emprunts actifs
- Changer son mot de passe

---

## 🗄️ Schéma de la base de données

```
CLIENT      (id, username, password, email, isBlocked, creation_date)
ADMINS      (id, username, password, email, creation_date)
LIVRE       (id, titre, auteur, categorie, isDispo, creation_date)
EMPRUNT     (id, client_id, livre_id, date_emprunt, date_limite, date_retour)
```
