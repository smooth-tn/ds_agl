package model;

public class Date {
    private int dayOfMonth;
    private int monthOfYear;
    private int year;

    public Date(int dayOfMonth, int monthOfYear, int year) {
        this.dayOfMonth = dayOfMonth;
        this.monthOfYear = monthOfYear;
        this.year = year;
    }

    public static Date aujourdhui() {
        java.time.LocalDate today = java.time.LocalDate.now();
        return new Date(today.getDayOfMonth(), today.getMonthValue(), today.getYear());
    }

    public static Date dansNJours(int n) {
        java.time.LocalDate future = java.time.LocalDate.now().plusDays(n);
        return new Date(future.getDayOfMonth(), future.getMonthValue(), future.getYear());
    }

    @Override
    public String toString() {
        return String.format("%02d/%02d/%04d", dayOfMonth, monthOfYear, year);
    }
}
