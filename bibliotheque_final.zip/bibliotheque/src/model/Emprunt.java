package model;

public class Emprunt {
    private int id;
    private int clientId;
    private int livreId;
    private String titreLivre;
    private String usernameClient;
    private Date dateEmprunt;
    private Date dateLimite;
    private Date dateRetour; // null if not returned yet

    public Emprunt(int id, int clientId, int livreId, String titreLivre,
                   String usernameClient, Date dateEmprunt, Date dateLimite, Date dateRetour) {
        this.id = id;
        this.clientId = clientId;
        this.livreId = livreId;
        this.titreLivre = titreLivre;
        this.usernameClient = usernameClient;
        this.dateEmprunt = dateEmprunt;
        this.dateLimite = dateLimite;
        this.dateRetour = dateRetour;
    }

    public int getId()              { return id; }
    public int getClientId()        { return clientId; }
    public int getLivreId()         { return livreId; }
    public String getTitreLivre()   { return titreLivre; }
    public String getUsernameClient(){ return usernameClient; }
    public Date getDateEmprunt()    { return dateEmprunt; }
    public Date getDateLimite()     { return dateLimite; }
    public Date getDateRetour()     { return dateRetour; }
    public boolean estRetourne()    { return dateRetour != null; }

    @Override
    public String toString() {
        String retour = estRetourne() ? dateRetour.toString() : "En cours";
        return String.format("[%d] Client: %-15s | Livre: %-30s | Emprunté: %s | Limite: %s | Retour: %s",
                id, usernameClient, titreLivre,
                dateEmprunt.toString(), dateLimite.toString(), retour);
    }
}
