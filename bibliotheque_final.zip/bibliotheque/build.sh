#!/bin/bash
# ─────────────────────────────────────────────
#  Script de compilation et d'exécution
#  Bibliothèque Management System
# ─────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$SCRIPT_DIR/src"
OUT="$SCRIPT_DIR/out"
LIB="$SCRIPT_DIR/lib/mysql-connector-j-9.6.0.jar"
MAIN="Main"

echo "📚 Bibliothèque — Build Script"
echo "────────────────────────────────"

# Check javac
if ! command -v javac &> /dev/null; then
    echo "[ERREUR] javac introuvable. Installez le JDK (Java 17+)."
    exit 1
fi

# Clean & create output dir
rm -rf "$OUT"
mkdir -p "$OUT"

# Compile
echo "[1/2] Compilation..."
find "$SRC" -name "*.java" > /tmp/sources.txt
javac -encoding UTF-8 -cp "$LIB" -d "$OUT" @/tmp/sources.txt "$SCRIPT_DIR/Main.java"

if [ $? -ne 0 ]; then
    echo "[ERREUR] Compilation échouée."
    exit 1
fi

echo "[2/2] Compilation réussie."
echo ""
echo "▶  Lancement de l'application..."
echo "────────────────────────────────"

java -cp "$OUT:$LIB" $MAIN

# Windows note (use semicolon instead of colon):
# java -cp "out;lib/mysql-connector-j-9.6.0.jar" Main
