package model;

public class Admin extends AbstractUser {
    public Admin(int id, String userName, String email) {
        super(id, userName, email);
    }

    @Override
    public String toString() {
        return String.format("[%d] %-20s | %s", id, userName, email);
    }
}
