package model;

import java.util.ArrayList;

public class Client extends AbstractUser {
    private boolean isBlocked;

    public Client(int id, String userName, String email, boolean isBlocked) {
        super(id, userName, email);
        this.isBlocked = isBlocked;
    }

    public boolean isBlocked()       { return isBlocked; }
    public void setBlocked(boolean b){ this.isBlocked = b; }

    @Override
    public String toString() {
        String statut = isBlocked ? "BLOQUÉ" : "Actif";
        return String.format("[%d] %-20s | %-30s | %s", id, userName, email, statut);
    }
}
