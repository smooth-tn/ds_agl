package model;

public class Livre {
    private int id;
    private String titre;
    private String auteur;
    private String categorie;
    private boolean isDispo;
    private Date dateAjout;

    public Livre(int id, String titre, String auteur, String categorie, boolean isDispo) {
        this.id = id;
        this.titre = titre;
        this.auteur = auteur;
        this.categorie = categorie;
        this.isDispo = isDispo;
        this.dateAjout = Date.aujourdhui();
    }

    public Livre(String titre, String auteur, String categorie) {
        this.titre = titre;
        this.auteur = auteur;
        this.categorie = categorie;
        this.isDispo = true;
        this.dateAjout = Date.aujourdhui();
    }

    public int getId()           { return id; }
    public String getTitre()     { return titre; }
    public String getAuteur()    { return auteur; }
    public String getCategorie() { return categorie; }
    public boolean isDispo()     { return isDispo; }
    public void setDispo(boolean dispo) { this.isDispo = dispo; }
    public String getDateAjout() { return dateAjout != null ? dateAjout.toString() : "N/A"; }

    @Override
    public String toString() {
        String dispo = isDispo ? "Disponible" : "Emprunté";
        return String.format("[%d] %-35s | %-20s | %-15s | %s",
                id, titre, auteur, categorie, dispo);
    }
}
