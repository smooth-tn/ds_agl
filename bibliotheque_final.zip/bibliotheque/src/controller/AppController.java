package controller;

import dao.*;
import model.*;
import utils.EmailValidation;
import view.View;

import java.util.List;

public class AppController {

    private final DatabaseManager db;
    private final ClientDAO  clientDAO;
    private final AdminDAO   adminDAO;
    private final LivreDAO   livreDAO;
    private final EmpruntDAO empruntDAO;

    public AppController() {
        db = DatabaseManager.getInstance();
        db.connect();
        db.initSchema();

        clientDAO  = new ClientDAO(db.getConnection());
        adminDAO   = new AdminDAO(db.getConnection());
        livreDAO   = new LivreDAO(db.getConnection());
        empruntDAO = new EmpruntDAO(db.getConnection());
    }

    // ═══════════════════════════════════════════════════════════
    //  BOUCLE PRINCIPALE
    // ═══════════════════════════════════════════════════════════

    public void run() {
        View.afficherBienvenue();

        boolean running = true;
        while (running) {
            int choix = View.afficherMenuConnexion();
            switch (choix) {
                case 1 -> loginClient();
                case 2 -> loginAdmin();
                case 3 -> inscription();
                case 0 -> running = false;
                default -> View.erreur("Choix invalide.");
            }
        }

        db.disconnect();
        System.out.println("\n  Au revoir ! 👋");
    }

    // ═══════════════════════════════════════════════════════════
    //  AUTHENTIFICATION
    // ═══════════════════════════════════════════════════════════

    private void loginClient() {
        String[] creds = View.formulaireConnexion();
        Client client = clientDAO.authentifier(creds[0], creds[1]);

        if (client == null) {
            View.erreur("Username/mot de passe incorrect ou compte bloqué.");
            View.pause();
            return;
        }
        View.succes("Bienvenue, " + client.getUserName() + " !");
        menuClient(client);
    }

    private void loginAdmin() {
        String[] creds = View.formulaireConnexion();
        Admin admin = adminDAO.authentifier(creds[0], creds[1]);

        if (admin == null) {
            View.erreur("Identifiants administrateur incorrects.");
            View.pause();
            return;
        }
        View.succes("Bienvenue, Administrateur " + admin.getUserName() + " !");
        menuAdmin(admin);
    }

    private void inscription() {
        String[] data = View.formulaireInscription();
        String username = data[0];
        String email    = data[1];
        String password = data[2];

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            View.erreur("Tous les champs sont obligatoires.");
            View.pause();
            return;
        }
        if (!EmailValidation.isValidEmail(email)) {
            View.erreur("Format d'email invalide.");
            View.pause();
            return;
        }
        if (password.length() < 4) {
            View.erreur("Le mot de passe doit contenir au moins 4 caractères.");
            View.pause();
            return;
        }

        Compte compte = new Compte(username, email, password);
        if (clientDAO.creerClient(compte)) {
            View.succes("Compte créé avec succès ! Vous pouvez maintenant vous connecter.");
        } else {
            View.erreur("Échec de la création du compte.");
        }
        View.pause();
    }

    // ═══════════════════════════════════════════════════════════
    //  MENU CLIENT
    // ═══════════════════════════════════════════════════════════

    private void menuClient(Client client) {
        boolean connecte = true;
        while (connecte) {
            int choix = View.afficherMenuClient(client.getUserName());
            switch (choix) {
                case 1 -> consulterCatalogue();
                case 2 -> rechercherLivre();
                case 3 -> emprunterLivre(client);
                case 4 -> retournerLivre(client);
                case 5 -> mesEmpruntsActifs(client);
                case 6 -> monHistorique(client);
                case 7 -> changerMdpClient(client);
                case 0 -> {
                    View.info("Déconnexion...");
                    connecte = false;
                }
                default -> View.erreur("Choix invalide.");
            }
        }
    }

    private void consulterCatalogue() {
        List<Livre> livres = livreDAO.tousLesLivres();
        View.afficherLivres(livres);
        View.pause();
    }

    private void rechercherLivre() {
        String titre = View.lireChaine("  Entrez le titre (ou une partie) : ");
        List<Livre> resultats = livreDAO.rechercherParTitre(titre);
        View.afficherLivres(resultats);
        View.pause();
    }

    private void emprunterLivre(Client client) {
        consulterCatalogue();

        int livreId = View.lireEntier("  Entrez l'ID du livre à emprunter (0 pour annuler) : ");
        if (livreId == 0) return;

        Livre livre = livreDAO.chercherParId(livreId);
        if (livre == null) {
            View.erreur("Livre introuvable.");
            View.pause();
            return;
        }
        if (!livre.isDispo()) {
            View.erreur("Ce livre est déjà emprunté.");
            View.pause();
            return;
        }

        // Check if client already has an active emprunt for this book
        List<Emprunt> actifs = empruntDAO.empruntsActifsClient(client.getId());
        for (Emprunt e : actifs) {
            if (e.getLivreId() == livreId) {
                View.erreur("Vous empruntez déjà ce livre.");
                View.pause();
                return;
            }
        }

        if (empruntDAO.emprunterLivre(client.getId(), livreId)) {
            livreDAO.setDispo(livreId, false);
            View.succes("Emprunt enregistré ! Durée : 14 jours.");
            View.info("Livre : " + livre.getTitre());
            View.info("À rendre avant : " + Date.dansNJours(14));
        } else {
            View.erreur("Erreur lors de l'enregistrement de l'emprunt.");
        }
        View.pause();
    }

    private void retournerLivre(Client client) {
        List<Emprunt> actifs = empruntDAO.empruntsActifsClient(client.getId());
        if (actifs.isEmpty()) {
            View.info("Vous n'avez aucun emprunt actif.");
            View.pause();
            return;
        }

        View.ligne();
        System.out.println("  VOS EMPRUNTS ACTIFS :");
        View.afficherEmprunts(actifs);

        int empruntId = View.lireEntier("  Entrez l'ID de l'emprunt à retourner (0 pour annuler) : ");
        if (empruntId == 0) return;

        // Validate ownership
        Emprunt cible = null;
        for (Emprunt e : actifs) {
            if (e.getId() == empruntId) { cible = e; break; }
        }
        if (cible == null) {
            View.erreur("Emprunt introuvable ou ne vous appartient pas.");
            View.pause();
            return;
        }

        if (empruntDAO.retournerLivre(empruntId)) {
            livreDAO.setDispo(cible.getLivreId(), true);
            View.succes("Retour enregistré. Merci !");
        } else {
            View.erreur("Erreur lors du retour.");
        }
        View.pause();
    }

    private void mesEmpruntsActifs(Client client) {
        List<Emprunt> actifs = empruntDAO.empruntsActifsClient(client.getId());
        View.ligne();
        System.out.println("  MES EMPRUNTS ACTIFS");
        View.afficherEmprunts(actifs);
        View.pause();
    }

    private void monHistorique(Client client) {
        List<Emprunt> historique = empruntDAO.historiqueClient(client.getId());
        View.ligne();
        System.out.println("  MON HISTORIQUE D'EMPRUNTS");
        View.afficherEmprunts(historique);
        View.pause();
    }

    private void changerMdpClient(Client client) {
        String[] data = View.formulaireChangerMdp();
        String ancien  = data[0];
        String nouveau = data[1];
        String confirm = data[2];

        // Verify old password
        Client verif = clientDAO.authentifier(client.getUserName(), ancien);
        if (verif == null) {
            View.erreur("Ancien mot de passe incorrect.");
            View.pause();
            return;
        }
        if (!nouveau.equals(confirm)) {
            View.erreur("Les deux nouveaux mots de passe ne correspondent pas.");
            View.pause();
            return;
        }
        if (nouveau.length() < 4) {
            View.erreur("Le nouveau mot de passe doit contenir au moins 4 caractères.");
            View.pause();
            return;
        }

        if (clientDAO.modifierPassword(client.getId(), nouveau)) {
            View.succes("Mot de passe modifié avec succès.");
        } else {
            View.erreur("Erreur lors de la modification.");
        }
        View.pause();
    }

    // ═══════════════════════════════════════════════════════════
    //  MENU ADMIN
    // ═══════════════════════════════════════════════════════════

    private void menuAdmin(Admin admin) {
        boolean connecte = true;
        while (connecte) {
            int choix = View.afficherMenuAdmin(admin.getUserName());
            switch (choix) {
                case 1 -> adminVoirLivres();
                case 2 -> adminAjouterLivre();
                case 3 -> adminSupprimerLivre();
                case 4 -> rechercherLivre();
                case 5 -> adminVoirClients();
                case 6 -> adminBloquerClient();
                case 7 -> adminDebloquerClient();
                case 8 -> adminVoirEmprunts();
                case 9 -> changerMdpAdmin(admin);
                case 0 -> {
                    View.info("Déconnexion...");
                    connecte = false;
                }
                default -> View.erreur("Choix invalide.");
            }
        }
    }

    private void adminVoirLivres() {
        List<Livre> livres = livreDAO.tousLesLivres();
        View.ligne();
        System.out.println("  CATALOGUE COMPLET  —  Total : " + livres.size() + " livre(s)");
        View.afficherLivres(livres);
        View.pause();
    }

    private void adminAjouterLivre() {
        String[] data = View.formulaireNouveauLivre();
        if (data[0].isEmpty() || data[1].isEmpty() || data[2].isEmpty()) {
            View.erreur("Tous les champs sont obligatoires.");
            View.pause();
            return;
        }
        Livre livre = new Livre(data[0], data[1], data[2]);
        if (livreDAO.ajouterLivre(livre)) {
            View.succes("Livre ajouté : \"" + data[0] + "\"");
        } else {
            View.erreur("Erreur lors de l'ajout.");
        }
        View.pause();
    }

    private void adminSupprimerLivre() {
        adminVoirLivres();
        int id = View.lireEntier("  ID du livre à supprimer (0 pour annuler) : ");
        if (id == 0) return;

        Livre livre = livreDAO.chercherParId(id);
        if (livre == null) {
            View.erreur("Livre introuvable.");
            View.pause();
            return;
        }

        String confirm = View.lireChaine("  Confirmer la suppression de \"" + livre.getTitre() + "\" ? (oui/non) : ");
        if (!confirm.equalsIgnoreCase("oui")) {
            View.info("Suppression annulée.");
            View.pause();
            return;
        }

        if (livreDAO.supprimerLivre(id)) {
            View.succes("Livre supprimé.");
        } else {
            View.erreur("Échec de la suppression.");
        }
        View.pause();
    }

    private void adminVoirClients() {
        List<Client> clients = clientDAO.tousLesClients();
        View.ligne();
        System.out.println("  LISTE DES CLIENTS");
        View.afficherClients(clients);
        View.pause();
    }

    private void adminBloquerClient() {
        adminVoirClients();
        int id = View.lireEntier("  ID du client à bloquer (0 pour annuler) : ");
        if (id == 0) return;

        Client client = clientDAO.chercherParId(id);
        if (client == null) {
            View.erreur("Client introuvable.");
            View.pause();
            return;
        }
        if (client.isBlocked()) {
            View.info("Ce client est déjà bloqué.");
            View.pause();
            return;
        }

        if (clientDAO.bloquerClient(id)) {
            View.succes("Client \"" + client.getUserName() + "\" bloqué.");
        } else {
            View.erreur("Erreur lors du blocage.");
        }
        View.pause();
    }

    private void adminDebloquerClient() {
        adminVoirClients();
        int id = View.lireEntier("  ID du client à débloquer (0 pour annuler) : ");
        if (id == 0) return;

        Client client = clientDAO.chercherParId(id);
        if (client == null) {
            View.erreur("Client introuvable.");
            View.pause();
            return;
        }
        if (!client.isBlocked()) {
            View.info("Ce client n'est pas bloqué.");
            View.pause();
            return;
        }

        if (clientDAO.debloquerClient(id)) {
            View.succes("Client \"" + client.getUserName() + "\" débloqué.");
        } else {
            View.erreur("Erreur lors du déblocage.");
        }
        View.pause();
    }

    private void adminVoirEmprunts() {
        List<Emprunt> emprunts = empruntDAO.tousEmpruntsActifs();
        View.ligne();
        System.out.println("  TOUS LES EMPRUNTS ACTIFS");
        View.afficherEmprunts(emprunts);
        View.pause();
    }

    private void changerMdpAdmin(Admin admin) {
        String[] data = View.formulaireChangerMdp();
        String ancien  = data[0];
        String nouveau = data[1];
        String confirm = data[2];

        Admin verif = adminDAO.authentifier(admin.getUserName(), ancien);
        if (verif == null) {
            View.erreur("Ancien mot de passe incorrect.");
            View.pause();
            return;
        }
        if (!nouveau.equals(confirm)) {
            View.erreur("Les deux nouveaux mots de passe ne correspondent pas.");
            View.pause();
            return;
        }
        if (nouveau.length() < 4) {
            View.erreur("Le nouveau mot de passe doit contenir au moins 4 caractères.");
            View.pause();
            return;
        }

        if (adminDAO.modifierPassword(admin.getId(), nouveau)) {
            View.succes("Mot de passe administrateur modifié.");
        } else {
            View.erreur("Erreur lors de la modification.");
        }
        View.pause();
    }
}
