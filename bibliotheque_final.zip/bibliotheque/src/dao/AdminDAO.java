package dao;

import model.Admin;

import java.sql.*;

public class AdminDAO {

    private final Connection con;

    public AdminDAO(Connection con) {
        this.con = con;
    }

    public Admin authentifier(String username, String password) {
        String sql = "SELECT * FROM ADMINS WHERE username = ? AND password = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next())
                return new Admin(rs.getInt("id"), rs.getString("username"), rs.getString("email"));
            return null;
        } catch (SQLException e) {
            System.err.println("[AdminDAO] Erreur authentification : " + e.getMessage());
            return null;
        }
    }

    public boolean modifierPassword(int adminId, String newPassword) {
        String sql = "UPDATE ADMINS SET password = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newPassword);
            ps.setInt(2, adminId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[AdminDAO] Erreur modification mdp : " + e.getMessage());
            return false;
        }
    }
}
