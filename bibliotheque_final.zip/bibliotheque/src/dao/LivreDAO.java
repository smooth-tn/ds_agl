package dao;

import model.Livre;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivreDAO {

    private final Connection con;

    public LivreDAO(Connection con) {
        this.con = con;
    }

    public boolean ajouterLivre(Livre livre) {
        String sql = "INSERT INTO LIVRE(titre, auteur, categorie) VALUES (?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, livre.getTitre());
            ps.setString(2, livre.getAuteur());
            ps.setString(3, livre.getCategorie());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[LivreDAO] Erreur ajout livre : " + e.getMessage());
            return false;
        }
    }

    public boolean supprimerLivre(int id) {
        // Cannot delete if there's an active emprunt
        String checkSql = "SELECT COUNT(*) FROM EMPRUNT WHERE livre_id = ? AND date_retour IS NULL";
        try (PreparedStatement check = con.prepareStatement(checkSql)) {
            check.setInt(1, id);
            ResultSet rs = check.executeQuery();
            rs.next();
            if (rs.getInt(1) > 0) {
                System.out.println("  [!] Impossible de supprimer : ce livre est actuellement emprunté.");
                return false;
            }
        } catch (SQLException e) {
            System.err.println("[LivreDAO] Erreur vérification emprunt : " + e.getMessage());
            return false;
        }

        String sql = "DELETE FROM LIVRE WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[LivreDAO] Erreur suppression livre : " + e.getMessage());
            return false;
        }
    }

    public Livre chercherParId(int id) {
        String sql = "SELECT * FROM LIVRE WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next())
                return new Livre(rs.getInt("id"), rs.getString("titre"),
                                 rs.getString("auteur"), rs.getString("categorie"),
                                 rs.getBoolean("isDispo"));
            return null;
        } catch (SQLException e) {
            System.err.println("[LivreDAO] Erreur recherche : " + e.getMessage());
            return null;
        }
    }

    public List<Livre> rechercherParTitre(String titre) {
        String sql = "SELECT * FROM LIVRE WHERE titre LIKE ? ORDER BY titre";
        List<Livre> liste = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + titre + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next())
                liste.add(new Livre(rs.getInt("id"), rs.getString("titre"),
                                    rs.getString("auteur"), rs.getString("categorie"),
                                    rs.getBoolean("isDispo")));
        } catch (SQLException e) {
            System.err.println("[LivreDAO] Erreur recherche titre : " + e.getMessage());
        }
        return liste;
    }

    public List<Livre> tousLesLivres() {
        String sql = "SELECT * FROM LIVRE ORDER BY id";
        List<Livre> liste = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next())
                liste.add(new Livre(rs.getInt("id"), rs.getString("titre"),
                                    rs.getString("auteur"), rs.getString("categorie"),
                                    rs.getBoolean("isDispo")));
        } catch (SQLException e) {
            System.err.println("[LivreDAO] Erreur liste livres : " + e.getMessage());
        }
        return liste;
    }

    public int compterLivres() {
        String sql = "SELECT COUNT(*) FROM LIVRE";
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[LivreDAO] Erreur comptage : " + e.getMessage());
        }
        return 0;
    }

    public void setDispo(int livreId, boolean dispo) {
        String sql = "UPDATE LIVRE SET isDispo = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, dispo);
            ps.setInt(2, livreId);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("[LivreDAO] Erreur set dispo : " + e.getMessage());
        }
    }
}
