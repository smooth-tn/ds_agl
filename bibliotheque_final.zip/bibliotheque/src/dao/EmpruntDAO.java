package dao;

import model.Date;
import model.Emprunt;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpruntDAO {

    private final Connection con;

    public EmpruntDAO(Connection con) {
        this.con = con;
    }

    /** Crée un emprunt pour un client sur un livre. Durée: 14 jours par défaut. */
    public boolean emprunterLivre(int clientId, int livreId) {
        String sql = "INSERT INTO EMPRUNT(client_id, livre_id, date_limite) " +
                     "VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 14 DAY))";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, clientId);
            ps.setInt(2, livreId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[EmpruntDAO] Erreur emprunt : " + e.getMessage());
            return false;
        }
    }

    /** Marque la date de retour pour un emprunt actif. */
    public boolean retournerLivre(int empruntId) {
        String sql = "UPDATE EMPRUNT SET date_retour = NOW() WHERE id = ? AND date_retour IS NULL";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, empruntId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[EmpruntDAO] Erreur retour : " + e.getMessage());
            return false;
        }
    }

    /** Active emprunts for a given client. */
    public List<Emprunt> empruntsActifsClient(int clientId) {
        String sql = "SELECT e.*, l.titre, c.username FROM EMPRUNT e " +
                     "JOIN LIVRE l ON e.livre_id = l.id " +
                     "JOIN CLIENT c ON e.client_id = c.id " +
                     "WHERE e.client_id = ? AND e.date_retour IS NULL ORDER BY e.id";
        return requeteEmprunts(sql, clientId);
    }

    /** All active emprunts (for admin). */
    public List<Emprunt> tousEmpruntsActifs() {
        String sql = "SELECT e.*, l.titre, c.username FROM EMPRUNT e " +
                     "JOIN LIVRE l ON e.livre_id = l.id " +
                     "JOIN CLIENT c ON e.client_id = c.id " +
                     "WHERE e.date_retour IS NULL ORDER BY e.date_limite";
        return requeteEmprunts(sql, -1);
    }

    /** Historique all emprunts for a client. */
    public List<Emprunt> historiqueClient(int clientId) {
        String sql = "SELECT e.*, l.titre, c.username FROM EMPRUNT e " +
                     "JOIN LIVRE l ON e.livre_id = l.id " +
                     "JOIN CLIENT c ON e.client_id = c.id " +
                     "WHERE e.client_id = ? ORDER BY e.id DESC";
        return requeteEmprunts(sql, clientId);
    }

    private List<Emprunt> requeteEmprunts(String sql, int clientId) {
        List<Emprunt> liste = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            if (clientId >= 0) ps.setInt(1, clientId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Timestamp tsEmprunt = rs.getTimestamp("date_emprunt");
                Timestamp tsLimite  = rs.getTimestamp("date_limite");
                Timestamp tsRetour  = rs.getTimestamp("date_retour");

                Date dateEmprunt = tsToDate(tsEmprunt);
                Date dateLimite  = tsToDate(tsLimite);
                Date dateRetour  = tsRetour != null ? tsToDate(tsRetour) : null;

                liste.add(new Emprunt(
                    rs.getInt("id"),
                    rs.getInt("client_id"),
                    rs.getInt("livre_id"),
                    rs.getString("titre"),
                    rs.getString("username"),
                    dateEmprunt, dateLimite, dateRetour
                ));
            }
        } catch (SQLException e) {
            System.err.println("[EmpruntDAO] Erreur requête : " + e.getMessage());
        }
        return liste;
    }

    private Date tsToDate(Timestamp ts) {
        if (ts == null) return null;
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTimeInMillis(ts.getTime());
        return new Date(cal.get(java.util.Calendar.DAY_OF_MONTH),
                        cal.get(java.util.Calendar.MONTH) + 1,
                        cal.get(java.util.Calendar.YEAR));
    }
}
